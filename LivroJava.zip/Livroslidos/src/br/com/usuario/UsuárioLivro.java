package br.com.usuario;

public class Usu�rioLivro {

		private Long IDusuario;
		private String nome;
		private String livro;
		
	public Long getIDusuario() {
			return IDusuario;
		}

		public void setIDusuario(Long iDusuario) {
			IDusuario = iDusuario;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getLivro() {
			return livro;
		}

		public void setLivro(String livro) {
			this.livro = livro;
		}

	public Usu�rioLivro() {
		// TODO Auto-generated constructor stub
	
		
	
	}

}
