package br.com.usuarioInterface;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ARMAZLIVROS.Conexao;
import br.com.interfaces.M�todosInterface;
import br.com.usuario.Usu�rioLivro;


public class UsuarioInterface implements M�todosInterface {

	private Connection conn;
	
	public UsuarioInterface() {
		// TODO Auto-generated constructor stub
		this.conn = new Conexao().ConexaoMYSQL();
	}

	@Override
	public void pesquisarID(Usu�rioLivro usuario) {
		
		// TODO Auto-generated method stub
String sql = "SELECT * FROM livros_ WHERE id_usuario = ?";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			stmt.setLong(1, usuario.getIDusuario());
		
			//execeuta a consulta sql
			
			ResultSet resultado = stmt.executeQuery();
			//retorna o resultado e repassa para o usuario
			while(resultado.next()) {
				usuario.setIDusuario(resultado.getLong(1));
				usuario.setNome(resultado.getString(2));
				usuario.setLivro(resultado.getString(3));
				
			}
			
			resultado.close();
		
			
			
		}catch(SQLException excecao) {
				throw new RuntimeException(excecao);
			
		
		}
	}

	@Override
	public void cadastrar(Usu�rioLivro usuario) {
		
		
		// TODO Auto-generated method stub

		String sql = "INSERT INTO livros_ (nome_pessoa, livros_lidos) VALUES (?,?)";
		try { PreparedStatement stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, usuario.getNome());
			stmt.setString(2, usuario.getLivro());
			stmt.execute();
			
			stmt.close();
		}
		
		catch(SQLException excecao) {
			throw new RuntimeException(excecao);
		}
	}

	@Override
	public void alterarnome(Usu�rioLivro usuario) {
		// TODO Auto-generated method stub
		String sql = "UPDATE livros_ set nome_pessoa = ? WHERE id_usuario = ?";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			//repassa os valores para a consulta sql
			stmt.setString(1, usuario.getNome());
			stmt.setLong(2, usuario.getIDusuario());
			//executa a consulta sql
			stmt.execute();
			//fecha a consulta
			stmt.close();
			
		}
		catch(SQLException excecao) {
			throw new RuntimeException(excecao);
	}

	}

	@Override
	public void alterarlivro(Usu�rioLivro usuario) {
		// TODO Auto-generated method stub
		String sql = "UPDATE livros_ set livros_lidos = ? WHERE id_usuario = ?";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			//repassa os valores para a consulta sql
			stmt.setString(1, usuario.getLivro());
			stmt.setLong(2, usuario.getIDusuario());
			
			//executa a consulta sql
			stmt.execute();
			//fecha a consulta
			stmt.close();
			
		}
		catch(SQLException excecao) {
			throw new RuntimeException(excecao);
	}

	}

	@Override
	public void excluir(Usu�rioLivro usuario) {
		// TODO Auto-generated method stub

String sql = "DELETE FROM livros_ WHERE id_usuario = ?  ";
		
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			//repassa os valores para a consulta sql
			stmt.setLong(1, usuario.getIDusuario());
			
			
			//executa a consulta sql
			stmt.execute();
			//fecha a consulta
			stmt.close();
					
				}
				catch(SQLException excecao) {
					throw new RuntimeException(excecao);
			
	}

	}
	
}
