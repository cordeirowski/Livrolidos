package br.com.interfaces;

import java.sql.Connection;

public interface ConexaoInterface {

	
	public interface Conexaointerface {
		
		public Connection ConexaoMySQL();

	}
}
