package br.com.interfaces;

import br.com.usuario.Usu�rioLivro;

public interface M�todosInterface {
	
	public void pesquisarID(Usu�rioLivro usuario);
	public void cadastrar(Usu�rioLivro usuario);
	public void alterarnome(Usu�rioLivro usuario);
	public void alterarlivro(Usu�rioLivro usuario);
	public void excluir(Usu�rioLivro usuario);

}
