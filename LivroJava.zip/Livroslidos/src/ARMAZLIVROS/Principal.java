package ARMAZLIVROS;

import javax.swing.JOptionPane;

import br.com.usuario.Usu�rioLivro;
import br.com.usuarioInterface.UsuarioInterface;

public class Principal {

	public Principal() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Usu�rioLivro usuario = new Usu�rioLivro();
		UsuarioInterface cadastro = new UsuarioInterface();
		
		Object acaoEscolha;
		Object alteracaoEscolha;
		Object desistirEscolha;
		
		Object[] acaoopcao = {"Cadastrar","Pesquisar ID","Sair"};
		Object[] alteraopcao = {"Alterar Nome","Alterar Livro","Excluir","Sair"};
		Object[] desistiropcao = {"sim","n�o"};
		
		do {
			acaoEscolha = JOptionPane.showInputDialog(null, "Escolha uma A��o:", "Escolha uma A��o:",
					JOptionPane.QUESTION_MESSAGE, null , acaoopcao, acaoopcao[0]);
			
			if(acaoEscolha == "Cadastrar") {
		
		usuario.setNome(JOptionPane.showInputDialog("Informe o seu nome:"));
		usuario.setLivro(JOptionPane.showInputDialog("Informe o livro lido:"));
		
	
		// cadastro o usuario no banco
		
		cadastro.cadastrar(usuario);
		
		// informa o sucesso do cadastro
		
		JOptionPane.showMessageDialog(null, "Dados cadastrados com sucesso");}
			
			else if (acaoEscolha =="Pesquisar ID") {
				
				//usuario.setNome(JOptionPane.showInputDialog("informe o ID a ser pesquisado"));
				
				String id = JOptionPane.showInputDialog("Informe o id a ser pesquisado");
				
				//converte string para long no banco de dados
				usuario.setIDusuario(Long.parseLong(id));
				
				cadastro.pesquisarID(usuario);
					
				//JOptionPane.showMessageDialog(null, "ID: " + usuario.getIdUsuario() + 
				//".\nNome: " + usuario.getNome() + ".\nE-MAIL: " + usuario.getEmail());
				
				alteracaoEscolha = JOptionPane.showInputDialog(null, "ID:" + usuario.getIDusuario() + ".\nNome:" + usuario.getNome() + ".\nproduto:" + usuario.getLivro() + ".","altera��o cadastral",
						JOptionPane.QUESTION_MESSAGE, null, alteraopcao, alteraopcao[0]);
			
				if(alteracaoEscolha == "Alterar Nome") {
					usuario.setNome(JOptionPane.showInputDialog("Informe o nome a ser alterado:"));
					
					
					//repassa os dados para o metoda alterar
					cadastro.alterarnome(usuario);
					
					JOptionPane.showMessageDialog(null, "Nome Alterado com sucesso!");
					
				}

			else if(alteracaoEscolha == "Alterar Livro") {
				usuario.setLivro(JOptionPane.showInputDialog("Informe o Livro a ser alterado:"));
				
				
				//repassa os dados para o metoda alterar
				cadastro.alterarlivro(usuario);
				
				JOptionPane.showMessageDialog(null, "Livro Alterado com sucesso!");
				
			}
			else if(alteracaoEscolha == "Excluir") {
				desistirEscolha = JOptionPane.showInputDialog(null, "tem certeza que deseja excluir?", "Desistir", JOptionPane.QUESTION_MESSAGE,
						null, desistiropcao, desistiropcao[0]);
				
					if(desistirEscolha == "sim") {
						cadastro.excluir(usuario);
						JOptionPane.showMessageDialog(null, "Usu�rio deletado com sucesso.");
					}
					else {
						JOptionPane.showMessageDialog(null, "Opera��o cancelada");
						
					}
			}
				
			}
			
		
		else {
			JOptionPane.showMessageDialog(null, "Aplica��o encerrada!");
			System.exit(0);
		}
				
		//encerra a aplica��o
	
		
		}while(acaoEscolha != "Sair");
	}
		
	}


