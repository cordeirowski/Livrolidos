package ARMAZLIVROS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import br.com.interfaces.ConexaoInterface;

public class Conexao implements ConexaoInterface {

	public Connection ConexaoMYSQL() {
		// TODO Auto-generated constructor stub
		try {
			
			//faz a conexao com driver
			return DriverManager.getConnection("jdbc:mysql://localhost/db_livros" + "?user=root&password=root");
		}	
	
		catch(SQLException excecao) {
			throw new RuntimeException(excecao);
		}
	}
	}


